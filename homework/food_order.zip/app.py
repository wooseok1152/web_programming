from flask import Flask, render_template, jsonify, request
app = Flask(__name__)
username_list = []
select_list = []
address_list = []
phone_number_list = []
information_dict = {"usernames" : username_list, "selects" : select_list, "addresses" : address_list, "phone_numbers" : phone_number_list}

@app.route('/', methods=['GET'])
def home():
    print("flask_server_is_working")
    return render_template("index.html")

@app.route('/customer_info_process', methods=['POST'])
def process_customer_info():
    print("process_customer_info function is working", "\n")
    username_list.append(request.form['username'])
    select_list.append(request.form['select'])
    address_list.append(request.form['address'])
    phone_number_list.append(request.form['phone_number'])
    print(username_list)
    # print(select_list)
    print(address_list)
    print(phone_number_list)
    return information_dict

if __name__ == '__main__':  
   app.run('0.0.0.0',port=5000,debug=True)